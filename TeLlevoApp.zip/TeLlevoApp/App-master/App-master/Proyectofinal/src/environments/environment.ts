// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
   firebaseConfig : {
    apiKey: "AIzaSyB__6dm7kUn0dbmedrbuwYsJTHve50JcOc",
    authDomain: "smproyectoduoc.firebaseapp.com",
    projectId: "smproyectoduoc",
    storageBucket: "smproyectoduoc.appspot.com",
    messagingSenderId: "740935565041",
    appId: "1:740935565041:web:d8e16f98e464aaf07cf350",
    measurementId: "G-XB8ZY4M5G3"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
