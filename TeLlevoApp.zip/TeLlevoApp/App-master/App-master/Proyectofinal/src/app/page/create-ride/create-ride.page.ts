import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-ride',
  templateUrl: './create-ride.page.html',
  styleUrls: ['./create-ride.page.scss'],
})
export class CreateRidePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
